<!DOCTYPE html>
<html lang="en">
<head>
  <title>Food Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">
<div class="row">
    <img src="foodies-and-friends.png" width="120px" height="100px">
  <center>
    <h1 style="margin-top:-50px;"><font color="brown">Yum...Yum...Yummy Recipes</font></h1>

    <img src="tasty.jpeg" style="height:45px;">
  </center>
</div>
</div>
<hr />


<h2><center>Gobi Manchurian</center></h2>
<img src="gobi.jpeg" width="650px" style="margin-left:300px;"><br><br>
<div class="container">
    <div class="panel panel-danger">
      <div class="panel-heading">Preparation:</div>
      <div class="panel-body">

Cut the cauliflower in big florets.<br>
Make a smooth batter of maida, corn flour, 1/4 tsp ginger, 1/4 tsp garlic paste, 1/4 tsp red
chilly powder and salt using water.<br>
The batter should be neither too flowy nor too thick.<br> It should be dripping consistency.<br>
In a frying pan heat oil for frying.<br>
 Dip the gobi florets in the batter and deep fry till golden brown. <br>
 Fry in small batches. Take ou on paper napkin and keep aside.<br>
In another pan heat oil and add the left ginger & garlic paste, dried red chillies broken
into halves and green chilies to it.<br>
Stir fry for a minute and then add salt and chopped capsicum cubes.<br>
 A minute later add chopped spring onions.<br>
Now add ajinomoto, soya sauce and tomato sauce to it. Mix well.<br>
Add fried gobi florets kept aside and sprinkle 1 tsp cornflour. Toss well.<br>
 Garnish it with finely chopped spring onions. Serve gobi manchurian hot.
</div>
</div>
</div>
</div>
</div>
</body>
</html>
