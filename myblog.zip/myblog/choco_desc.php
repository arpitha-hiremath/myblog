<!DOCTYPE html>
<html lang="en">
<head>
  <title>Food Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">
<div class="row">
    <img src="foodies-and-friends.png" width="120px" height="100px">
  <center>
    <h1 style="margin-top:-50px;"><font color="brown">Yum...Yum...Yummy Recipes</font></h1>

    <img src="tasty.jpeg" style="height:45px;">
  </center>
</div>
</div>
<hr />


<h2><center>Chocolate cream pie</center></h2>
<img src="chocopie.jpg" width="650px" style="margin-left:300px;"><br><br>
<div class="container">
<div class="panel panel-danger">
  <div class="panel-heading">Preparation:</div>
  <div class="panel-body">

 In a medium bowl, whisk together the flour, and salt.<br>
 Cut in the shortening until it's in lumps the size of small peas.<br>
 Dice the butter into 1/2" pieces, and cut into the mixture until you have flakes of butter the
 size of your fingernail.<br>
 Add the water, two tablespoons at a time, mixing with a fork as you sprinkle the water into the dough.<br>

  When the dough is moist enough to hold together when you squeeze it, transfer it to a piece of wax or parchment paper. It's ok if there are dry spots in the pile. Use a spray bottle of water to lightly spritz these places; that way you'll add just enough water to bring the dough together without adding too much or creating a wet spot.
    Fold it over on itself three or four times to bring it together, then pat it into a disk 3/4" thick
    Roll the disk on its edge, like a wheel, to smooth out the edges. This step will ensure your dough will roll out evenly, without a lot of cracks and splits at the edges later. Wrap in plastic and refrigerate for 30 minutes before rolling.
    To blind bake the crust: Preheat the oven to 400°F. <br>
    Lightly grease a 9" pie pan that's at least 2" deep. This will make serving the pie easier after it's finished.
    Roll out the pastry for the pie to a 13" circle. Transfer it to the prepared pan, and trim the edges so they overlap the edge by an inch all the way around. Tuck the edges up and under, and flute them. Put the lined pie pan in the refrigerator to chill for 10 minutes.
    Line the crust with foil or parchment paper, and fill it with pie weights or dried beans.
    Bake the crust for 20 minutes. <br>Remove it from the oven, and gently remove foil or parchment
     with the weights or beans. Return the crust to the oven for 10 to 20 more minutes, until it's
     golden brown all over.<br> If the edges of the crust start becoming too brown, cover
     them with a pie shield, or strips of aluminum foil.<br> Remove the crust from the oven
      and cool completely.<br>
    Filling
    Place the chopped chocolate, butter, and vanilla extract in a 2-quart mixing bowl; set aside.<br>
    In a medium saucepan away from heat, whisk together the sugar, cornstarch, cocoa, espresso powder, and salt. Whisk in 1/4 cup of cold heavy cream until the mixture is smooth, with no lumps. Repeat with another 1/4 cup of the cream. Whisk in the egg yolks.
    Place the saucepan over medium heat, and gradually whisk in the remaining cream and milk.<br>
    Bring to a boil, whisking constantly as the mixture thickens; boil for 1 minute.<br>
    Remove the pan from the heat and pour the mixture over the reserved chocolate and butter.<br>
    Whisk until the chocolate is melted and the mixture is smooth.<br>
    Pass the filling through a strainer into a bowl to remove any lumps.<br>
    Place plastic wrap or buttered parchment paper on the surface to prevent a skin from
     forming, and chill thoroughly.<br>
    Topping
    Place the heavy cream in a chilled mixing bowl.<br>
    Whip until the whisk begins to leave tracks in the bowl.<br>
    Add the sugar and vanilla and whip until the cream holds a medium peak.<br>
    Assembly
    Transfer the cooled filling to the cooled, baked pie crust. Level the top with the back of a spoon or an offset spatula.
    Spoon or pipe the whipped cream on top.<br>
    Chill the pie until ready to serve.<br>
  </div>
  </div>
  </div>
  </div>
</div>
  </body>
  </html>
